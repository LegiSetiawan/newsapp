package com.udah.newsapp.categori

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.udah.newsapp.R
import com.udah.newsapp.adapter.NewsAdapter
import com.udah.newsapp.model.Article
import com.udah.newsapp.model.ResponseServer
import com.udah.newsapp.network.ConfigNetwork
import kotlinx.android.synthetic.main.activity_technology.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class TechnologyActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_technology)

        ConfigNetwork.getRetrofit().getTechnology().enqueue(object : Callback<ResponseServer> {
            override fun onFailure(call: Call<ResponseServer>, t: Throwable) {
                progresT.visibility = View.GONE
                Log.d("error server",t.message)
            }

            override fun onResponse(
                call: Call<ResponseServer>,
                response: Response<ResponseServer>
            ) {
                Log.d("response server",response.message())

                if (response.isSuccessful) {
                    progresT.visibility = View.GONE
                    val status = response.body()?.status
                    if (status == "ok") {
                        val articles = response.body()?.articles

                        showArticles(articles)
                    }
                }
            }
        })
    }

    private fun showArticles(articles: ArrayList<Article>?) {
        listTechnology.adapter = NewsAdapter(articles)
    }
}
