package com.udah.newsapp.network

import com.udah.newsapp.model.ResponseServer
import retrofit2.Call
import retrofit2.http.GET

interface NewsService {
    @GET("v2/everything?q=general&from=2021-03-03&to=2021-03-03&sortBy=popularity&apiKey=c061111314204e438fb75841651ac161")
    fun getNewsGeneral(): Call<ResponseServer>

    @GET("v2/top-headlines?country=jp&category=business&apiKey=c061111314204e438fb75841651ac161")
    fun getDataNewsScience(): Call<ResponseServer>

    @GET("v2/everything?q=technology&from=2021-02-07&sortBy=publishedAt&apiKey=c061111314204e438fb75841651ac161")
    fun getTechnology(): Call<ResponseServer>

    @GET("v2/everything?q=sports&from=2021-03-03&to=2021-03-03&sortBy=popularity&apiKey=c061111314204e438fb75841651ac161")
    fun getDataNewsSports(): Call<ResponseServer>
}