package com.udah.newsapp.model

 class Article {
    var author: String? = null
    var title: String? = null
    var description: String? = null
    var urlToImage: String? = null
    var publishedAt: String? = null
}