package com.udah.newsapp.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.udah.newsapp.R
import kotlinx.android.synthetic.main.activity_detail.*

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val author = intent.getStringExtra("athr")
        val title = intent.getStringExtra("ttl")
        val description = intent.getStringExtra("desk")
        val img = intent.getStringExtra("img")
        val plsd = intent.getStringExtra("plsd")

        authorD.text = author
        titleD.text = title
        deskD.text = description
        publishedD.text =plsd

        Glide.with(this).load(img).into(imgD)
    }
}