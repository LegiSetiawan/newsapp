package com.udah.newsapp

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import com.udah.newsapp.categori.GeneralActivity
import com.udah.newsapp.categori.ScienceActivity
import com.udah.newsapp.categori.SportsActivity
import com.udah.newsapp.categori.TechnologyActivity
import kotlinx.android.synthetic.main.activity_home.*

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        btnGnrl.setOnClickListener {
            val intent =  Intent(this, GeneralActivity::class.java)
            Toast.makeText(this, "load to news general", Toast.LENGTH_SHORT).show()
            startActivity(intent)
        }
        btnScience.setOnClickListener {
            val intent =  Intent(this, ScienceActivity::class.java)
            Toast.makeText(this, "load to news science", Toast.LENGTH_SHORT).show()
            startActivity(intent)
        }
        btnTech.setOnClickListener {
            val intent =  Intent(this, TechnologyActivity::class.java)
            Toast.makeText(this, "load to news Technology", Toast.LENGTH_SHORT).show()
            startActivity(intent)
        }
        btnSports.setOnClickListener {
            val intent =  Intent(this, SportsActivity::class.java)
            Toast.makeText(this, "load to news sports", Toast.LENGTH_SHORT).show()
            startActivity(intent)
        }
    }
}