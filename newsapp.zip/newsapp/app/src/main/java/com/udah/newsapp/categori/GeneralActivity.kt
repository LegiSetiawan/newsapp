package com.udah.newsapp.categori

import android.content.Context
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.Menu
import android.view.View
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import com.udah.newsapp.R
import com.udah.newsapp.adapter.NewsAdapter
import com.udah.newsapp.model.Article
import com.udah.newsapp.model.ResponseServer
import com.udah.newsapp.network.ConfigNetwork
import kotlinx.android.synthetic.main.activity_general.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class GeneralActivity : AppCompatActivity() {
    private lateinit var articles:ArrayList<Article>
    private lateinit var adapterItem:NewsAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_general)

        if (isConnect()) {
        ConfigNetwork.getRetrofit().getNewsGeneral().enqueue(object :Callback<ResponseServer> {
            override fun onFailure(call: Call<ResponseServer>, t: Throwable) {
                progres.visibility = View.GONE
                Log.d("error server",t.message)
            }

            override fun onResponse(
                call: Call<ResponseServer>,
                response: Response<ResponseServer>
            ) {
                Log.d("response server",response.message())

                if (response.isSuccessful) {
                    progres.visibility = View.GONE
                    val status = response.body()?.status
                    if (status == "ok") {
                        val articles = response.body()?.articles

                        showArticles(articles)
                    }
                }
            }
        })
    }else {
            progres.visibility = View.GONE
            Toast.makeText(this, "jaringan internet tidak tersedia", Toast.LENGTH_SHORT).show()
        }
    }

    fun isConnect():Boolean {
        val connect: ConnectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return connect.activeNetworkInfo != null && connect.activeNetworkInfo.isConnected
    }

    private fun showArticles(articles: ArrayList<Article>?) {
        listGeneral.adapter = NewsAdapter(articles)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main,menu)
        var searhItem = menu?.findItem(R.id.action_seach)
        var serchView = searhItem?.actionView as SearchView

        serchView.setOnQueryTextListener(object :SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (TextUtils.isEmpty(query)) {
                }
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {

                return true
            }
        })

        return super.onCreateOptionsMenu(menu)
    }

}