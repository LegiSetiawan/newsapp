package com.udah.newsapp.model

class ResponseServer {
    var status: String? = null
    var totalResults: Int?= null
    var articles: ArrayList<Article>? = null

}