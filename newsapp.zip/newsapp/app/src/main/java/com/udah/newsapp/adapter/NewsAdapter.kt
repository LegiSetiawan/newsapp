package com.udah.newsapp.adapter

import android.content.Intent
import android.telecom.Call
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.udah.newsapp.R
import com.udah.newsapp.detail.DetailActivity
import com.udah.newsapp.model.Article
import kotlinx.android.synthetic.main.item_news.view.*

class NewsAdapter(var articles: ArrayList<Article>?) :RecyclerView.Adapter<NewsAdapter.GeneralHolder> () {
    class GeneralHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val author = itemView.txtAuthor
        val title = itemView.txtTitle
        val description = itemView.txtDesk
        val  image = itemView.txtUrlTo
        val publishedAt = itemView.txtPublished

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GeneralHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_news,parent,false)
        val holder = GeneralHolder(view)
        return holder
    }

    override fun getItemCount(): Int {
        return articles?.size ?:0
    }

    override fun onBindViewHolder(holder: GeneralHolder, position: Int) {
        holder.author.text = articles?.get(position)?.author
        holder.title.text = articles?.get(position)?.title
        holder.description.text = articles?.get(position)?.description
        Glide.with(holder.itemView.context).load(articles?.get(position)?.urlToImage).into(holder.image)
        holder.publishedAt.text = articles?.get(position)?.publishedAt

        //action klik
        holder.itemView.setOnClickListener {
        val intent = Intent(holder.itemView.context,DetailActivity::class.java)
        intent.putExtra("athr",articles?.get(position)?.author)
        intent.putExtra("ttl",articles?.get(position)?.title)
        intent.putExtra("desk",articles?.get(position)?.description)
        intent.putExtra("img",articles?.get(position)?.urlToImage)
        intent.putExtra("plsd",articles?.get(position)?.publishedAt)
        holder.itemView.context.startActivity(intent)
        }
    }
}